const API_PATH = {
  LOGIN: '/connect/token',
  GRAPHQL: '/api/graphql',

  GET_QUESTION: '/api/questions/getall',
  ADD_QUESTION: '/api/questions',



}

export default API_PATH;
