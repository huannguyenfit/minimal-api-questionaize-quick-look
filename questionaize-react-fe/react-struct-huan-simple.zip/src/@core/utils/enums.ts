
export enum TypeInputEnum {
  SingleSelection = 1,
  MultipleSelection = 2,
}
